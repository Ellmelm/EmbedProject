// #define WIFI_SSID "Elm"
// #define WIFI_PASS "12345678"
#define WIFI_SSID "Bostonhandsomeandcool"
#define WIFI_PASS "11111111"

#define NETPIE_CLIENT_ID "36553727-d539-4446-aca6-813c0fe7c607"
#define NETPIE_TOKEN     "XrnFhS3Zykf3vfDg2wscMTycWJkhR75G"
#define NETPIE_SECRET    "UVjE2FHCfxVaXgn4JZmvdZnXpdVhudvg"

#define MQTT_SERVER "mqtt.netpie.io"
#define MQTT_PORT 1883