// #define WIFI_SSID "yada"
// #define WIFI_PASS "proudppp"
#define WIFI_SSID "Bostonhandsomeandcool"
#define WIFI_PASS "11111111"
// #define WIFI_SSID "Elm"
// #define WIFI_PASS "12345678"

#define NETPIE_CLIENT_ID "26558ad6-b25c-4ead-8f68-cc4850787ac7"
#define NETPIE_TOKEN     "EdEvqhyckP2crZHL1p82682Eh2L1rgS2"
#define NETPIE_SECRET    "Ty76kZ1PS7kRSXexRirCen1naqC855DM"

#define MQTT_SERVER "mqtt.netpie.io"
#define MQTT_PORT 1883

#define FIREBASE_URL "https://embedproject-9e1dc-default-rtdb.asia-southeast1.firebasedatabase.app/"
// ========== FIREBASE STORAGE UPLOAD ==========
#define FIREBASE_STORAGE_UPLOAD_URL "https://firebasestorage.googleapis.com/v0/b/embedproject-9e1dc.appspot.com/o/last.jpg?uploadType=media"
#define DISCORD_WEBHOOK "https://discordapp.com/api/webhooks/1440695358698029056/TBaoO1TacVQooZ0x0T3aKG_XkIL16ixgmMO5u-KIcfmCJV9Woxzvmev_BvCOHKJDOV-g"
#define DISCORD_USERNAME "Hamster Alert Bot"
